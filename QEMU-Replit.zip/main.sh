install-pkg qemu
qemu-system-x86_64 IMAGE.iso
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.  qemu-system-x86_64 #ARGS